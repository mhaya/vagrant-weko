default:白背景用
dark:黒背景用
